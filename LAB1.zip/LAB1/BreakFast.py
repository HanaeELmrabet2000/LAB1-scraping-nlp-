import requests
from bs4 import BeautifulSoup
import pymongo

titre = []
prop = []
tmp = []
links=[]
ingredient=[]
rct=[]
acteurs=[]
divs=[]
prsn=[]
# Récupérer le contenu de la page web
result = requests.get("https://www.fatafeat.com/recipes-list/134-%D9%81%D8%B7%D9%88%D8%B1")
src = result.content
soup = BeautifulSoup(src, "lxml")

# Trouver les éléments de la page web contenant les données
titres = soup.find_all("h2", {"class": "mb-0 semibold-font"})
propriéte = soup.find_all("div", {"class": "tabkha-details rounded-pill py-1 me-1 medium-font"})
acteur = soup.find_all("h3",{"class":"pt-5 recipe-chef-name medium-font"})
div = soup.find_all("a",{"class":"recipe-real-image"})
# Boucle pour extraire et stocker les données
for i in range(len(titres)):
    titre.append(titres[i].text)
    prop.append(propriéte[i].text)
    acteurs.append(acteur[i].text)
    #links.append(titre[i].find("a").attrs['href'])
    divs.append(div[i].text)
    links.append(div[i].attrs['href'])
for link in links:
    result = requests.get(link)
    src = result.content
    soup = BeautifulSoup(src, "lxml")
    ingredients = soup.find("div",{"class":"row px-0 px-lg-3 ingredients"})
    if ingredients  is not None:
        ingredient.append(ingredients.text)
    else:
        ingredient.append("ingredient non disponibles")
    ingredient.append(ingredients.text)
    recettes = soup.find("div", {"class": "row px-0 px-lg-3 preparationWay"})
    if recettes is not None:
        rct.append(recettes.text)
    else:
        rct.append("Recettes non disponibles")
    #personne = soup.find("div",{"class":"col-4 text-center"})
    #prsn.append(personne.text)


# Connexion à la base de données MongoDB
client = pymongo.MongoClient("mongodb://localhost:27017")
db = client["scraping"]
collection = db["scraping1"]

# Insérer les données dans la base de données
for i in range(len(titres)):
    recette = {"titre": titre[i], "propriété": prop[i], "ingredients": ingredient[i], "recettes":rct[i]}
    collection.insert_one(recette)

# Fermer la connexion à la base de données
client.close()